package models;

import java.util.LinkedList;
import java.util.Queue;

import enums.*;

public class Elevator {
    String elevatorId;
    int currentFloor;
    Direction currentDir;
    State currState;
    Display display;
    Queue<Integer> requestQueue;

    public Elevator(String id, Display display){
        this.elevatorId = id;
        this.currentFloor = 0;
        this.currentDir = null;
        this.currState = State.HALT;
        this.display = display;
        this.requestQueue = new LinkedList<>();
    }

    public void moveTo(int floorNum){
        //if currentFloor == floorNum
        display.notify(this.elevatorId,this.currentFloor,this.currentDir,this.currState);
    }

    public void addRequest(int floor){
        requestQueue.offer(floor);
    }

    public String getId(){
        return this.elevatorId;
    }
}
